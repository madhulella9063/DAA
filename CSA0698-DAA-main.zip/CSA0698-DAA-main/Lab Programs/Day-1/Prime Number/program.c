#include<stdio.h>
int main()
{
	int n,i;
	int count=0;
	printf("Enter the Number: ");
	scanf("%d",&n);
	for(i=2;i<=n-1;i++)
	{
		if(n%i==0)
		{
			count++;
		}
	}
	if(count==0)
	{
		printf("It is Prime Number.");
		
	}
	else
	{
		printf("It is not Prime Numebr.");
	}
	
}
