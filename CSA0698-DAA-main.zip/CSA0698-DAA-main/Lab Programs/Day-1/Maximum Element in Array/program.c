#include<stdio.h>
int main()
{
	int n,i;
	printf("Enter No of Elements in the Array: ");
	scanf("%d",&n);
	int arr[n];
	printf("------Enter the Elements For Array-------\n");
	for(i=0;i<n;i++)
	{
		printf("Enter the Element[%d]: ",i+1);
		scanf("%d",&arr[i]);
	}
	int max_value=arr[0];
	for(i=1;i<n;i++)
	{
		if(arr[i]>max_value)
		{
			max_value=arr[i];
		}
	}
	
	printf("Maximum Element in the Array: %d",max_value);
	
}
